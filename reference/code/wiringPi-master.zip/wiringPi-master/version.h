#define VERSION "3.7"
#define VERSION_MAJOR 3
#define VERSION_MINOR "7"
